﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.IO.Pipes;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pipe_practice
{
    public partial class serverForm : Form
    {
        NamedPipeServerStream pipeServer =
    new NamedPipeServerStream("testpipe", PipeDirection.InOut, 1, PipeTransmissionMode.Message, PipeOptions.Asynchronous);

        public serverForm()
        {
            InitializeComponent();
        }

        private void serverForm_Load(object sender, EventArgs e)
        {
            ThreadPool.QueueUserWorkItem(delegate
            {
                pipeServer.BeginWaitForConnection((o) =>
                {
                    NamedPipeServerStream pServer = (NamedPipeServerStream)o.AsyncState;
                    pServer.EndWaitForConnection(o);
                    StreamReader sr = new StreamReader(pServer);
                    while (true)
                    {
                        this.Invoke((MethodInvoker)delegate { lsvMessage.Text =Convert.ToString(  Convert.ToInt16( sr.ReadLine()) * 3 +5); });//輸出client*3+5的數字

                    }
                }, pipeServer);
            });
        }
    }
}
